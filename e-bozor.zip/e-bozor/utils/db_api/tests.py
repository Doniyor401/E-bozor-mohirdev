import asyncio

# from db_commands import Database
from loader import db

async def test():
    # db = Database()
    await db.create()

    print("Users jadvalini yaratamiz...")
    await db.drop_users()
    await db.create_table_users()
    print("Yaratildi")

    print("Foydalanuvchilarni qo'shamiz")

    await db.add_user("Olim", "Zakirov", 123456789)
    await db.add_user("Ramazon", "Pardayev", 12341123)
    await db.add_user("Umid", "Avazov", 131231)
    await db.add_user("Adxam", "Sobirov", 23324234)
    await db.add_user("Isom", "Ismatullayev", 4388229)
    print("Qo'shildi")

    users = await db.select_all_users()
    print(f"Barcha foydalanuvchilar: {users}")

    user = await db.select_user(id=5)
    print(f"Foydalanuvchi: {user}")

    #### Mahsulotlar uchun test
    print("Products jadvalini yaratamiz...")
    await db.drop_products()
    await db.create_table_products()
    await db.add_product(
        "food",
        "🫕 Еда",
        "tea",
        "🍵 Чай",
        "Ahmad Tea.",
        "https://ahmadtea.my/wp-content/uploads/2020/08/AHMA-BlackTeas-Earl-Grey-100tb-GT.png",
        10,
        "Ahmad чай",
    )
    await db.add_product(
        "food",
        "🫕 Еда",
        "tea",
        "🍵 Чай",
        "Ahmad Tea.",
        "https://dibaonline.de/media/image/product/196/lg/ahmad-tea-english-breakfast-500g-loose-leaf-tea.png",
        20,
    )
    await db.add_product(
        "food",
        "🫕 Еда",
        "coffee",
        "☕ Кофе",
        "Nescafe Gold",
        "https://www.nescafe.com/mt/sites/default/files/2020-07/nescafe-gold-blend-jar-front-pitch.png",
        15,
        "Классный кофе со вкусом молоко"
    )
    await db.add_product(
        "food",
        "🫕 Еда",
        "milk",
        "🥛 Молоко",
        "Nestle Sut. 1L",
        "https://100comments.com/wp-content/uploads/2017/03/nestle-just-milk-low-fat.jpg",
        2,
        'Molokoku'
    )
    await db.add_product(
        "electronics",
        "🖥️ Электроника",
        "phone",
        "📱 Смартфоны",
        "iPhone 13",
        "https://9to5mac.com/wp-content/uploads/sites/6/2021/09/iphone-13-pro-max-tidbits-9to5mac.jpg",
        1000,
        "Новый iPhone 13",
    )
    await db.add_product(
        "electronics",
        "🖥️ Электроника",
        "laptop",
        "💻 Ноутбуки",
        "macBook Air",
        "https://checheelectronics.co.ke/wp-content/uploads/2021/06/NL244a1b_2.jpg",
        1600,
        'Zor noutbook'
    )

    await db.add_product(
        "kiyim",
        "👕 Одежда",
        "yozgi",
        "🩳 Летные одежды",
        "Магазин 1Fit sports",
        "https://ireland.apollo.olxcdn.com/v1/files/oedv3pxrselm2-UA/image;s=1500x2000",
        5,
        "Разные одежды под ваш вкус \n Телефоны: +998 93 1234567",
    )
    await db.add_product(
        "kiyim",
        "👕 Одежда",
        "yozgi",
        "🩳 Летные одежды",
        "Nike and adidas",
        "https://www.wantedshop.ru/upload/resize_cache/iblock/fa2/350_500_1/cwviyhvwd38aemw987pmmlmb8y3cj2dm.jpg",
        5,
        "Спортивные одежды.\n Телефоны: +998 93 1234567",
    )

    await db.add_product(
        "kiyim",
        "👕 Одежда",
        "qishgi",
        "🧣 Зимные одежды",
        "Шубы",
        "https://mysteryfurs.ru/img/7/3/3/191.jpg",
        3,
        "Кишда совик котмасдан юринг \n Телефоны: +998 93 1234567"
    )
    await db.add_product(
        "kiyim",
        "👕 Одежда",
        "qishgi",
        "🧣 Зимные одежды",
        "Куртки",
        "https://images.uzum.uz/cjfl5k4jvf2pi6u7b0c0/t_product_540_high.jpg",
        5,
        "Барча турдаги кишги курткалар факат бизда \nTелефон ракамларимиз: +998 97 1234567"
    )

    categories = await db.get_categories()
    print(f"{categories=}")
    print(categories[0]["category_code"])

    subcategories = await db.get_subcategories("food")
    print(f"{subcategories=}")
    print(subcategories[0]["subcategory_name"])

    count_products = await db.count_products("food")
    print(f"{count_products=}")

    count_sub_products = await db.count_products("food", "tea")
    print(f"{count_sub_products=}")

    products = await db.get_products("food", "tea")
    print(f"{products=}")

    product = await db.get_product(1)
    print(f"{product=}")
    product = await db.get_product(5)
    print(f"{product=}")


loop = asyncio.get_event_loop()
loop.run_until_complete(test())